﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace WriteRandomData
{
    class Program
    {

        internal static string DataFileName = "qfgrandomdata.dat";
        static void Main(string[] args)
        {

            int auto_exit_seconds = 30;
            long totalSize = 1 * 1024 * 1024; // 每次写入100MB数据
            byte[] buffer = Enumerable.Repeat((byte)0x0, (int)totalSize).ToArray(); // 生成100MB大小的字节数组，填充为0x0
            string[] drives = Directory.GetLogicalDrives(); // 获取所有盘符
            int xunhuancishu = 20;
            Console.CursorVisible = false;
            Console.WriteLine($"\r\n欢迎使用潜伏哥自动写盘程序，本程序原理为向硬盘空余空间写入随机数据，直到占满磁盘剩余空间，以此预防隐私数据被不法恢复！");
            Console.WriteLine($"\r\n温馨提示：循环填充数据的次数越多，恢复数据难度越高。在硬盘上循环填充随机数据9次以后，被删除数据就基本没有恢复的可能。");
            Console.WriteLine($"\r\n本程序默认为循环写入{xunhuancishu}次，如需写入更多次数，可重复运行本工具。");
            Console.WriteLine($"\r\n温馨提示：程序正常退出会自动清理所有写入的随机数据，如果程序异常退出，再次运行本程序或手动删除每个分区根目录下的{DataFileName}文件即可。");
            bool is_need_clear = false;

            foreach (string drive in drives)
            {
                if (File.Exists($"{drive}{DataFileName}"))
                {
                    is_need_clear = true;
                }
            }
            if (is_need_clear == false)
            {
                for (int i = 1; i <= xunhuancishu; i++)
                {
                    long writtenSize = 0; // 已经写入数据大小
                    Console.WriteLine($"正在执行第{i}次写入，总共需要写入{xunhuancishu}次...");
                    foreach (string drive in drives)
                    {

                        DriveInfo driveInfo = new DriveInfo(drive);
                        if (!driveInfo.Name.ToUpper().Contains("C:"))
                        {
                            if (driveInfo.IsReady && driveInfo.DriveType != DriveType.Network)
                            {
                                Console.WriteLine($"正在写入盘符{drive}...");
                                try
                                {
                                    using (FileStream fileStream = new FileStream($"{drive}{DataFileName}", FileMode.CreateNew, FileAccess.Write))
                                    {
                                        while (driveInfo.AvailableFreeSpace > totalSize) // 写满盘符
                                        {
                                            fileStream.Write(buffer, 0, (int)totalSize);
                                            writtenSize += totalSize;
                                            ShowInfo($"已经写入{writtenSize / 1024 / 1024}MB，磁盘剩余空间{(driveInfo.AvailableFreeSpace) / 1024 / 1024}MB");
                                            //Thread.Sleep(1000);
                                        }
                                        Console.WriteLine($"写入完成，已写入{writtenSize / 1024 / 1024}MB，磁盘剩余空间{(driveInfo.AvailableFreeSpace) / 1024 / 1024}MB");

                                    }
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"写入盘符{drive}出现异常：{ex.Message}");
                                }
                                Console.WriteLine($"写入盘符{drive}完成");
                                //System.Windows.Forms.MessageBox.Show("Test");
                            }
                        }
                    }

                    DeleteDat();
                }
                DeleteDat();
            }
            else
            {
                DeleteDat();
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine($"");
                Console.WriteLine($"");
                Console.WriteLine($"");

                for (int i = 0; i < auto_exit_seconds; i++)
                {
                    ShowInfo($"已将本机所有的随机数据清理完成，如需使用随机数据填充功能，请重新运行本程序！程序即将于{auto_exit_seconds - i}秒后自动退出。");
                    Thread.Sleep(1000);
                }
                Console.ResetColor();

            }

        }

        public static void ShowInfo(string s)
        {
            int cursorLeft = Console.CursorLeft;
            Console.SetCursorPosition(0, Console.CursorTop);
            Console.Write(s);
            Console.SetCursorPosition(cursorLeft, Console.CursorTop);
        }


        internal static void DeleteDat()
        {
            string[] drives = Directory.GetLogicalDrives(); // 获取所有盘符

            foreach (string drive in drives)
            {
                try
                {
                    string file = $"{drive}{DataFileName}";
                    if (File.Exists(file))
                    {
                        File.Delete(file);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"删除盘符{drive}的数据出现异常：{ex.Message}");
                }
            }
            Console.WriteLine("随机数据文件清理完成。");

        }

    }
}
